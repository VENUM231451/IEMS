# Developer Handover Guide

This document outlines the architecture of the Counsellor Event System and provides specific instructions for integrating **CAS Authentication** and **Outlook/Exchange Email Notifications**.

## 1. System Overview
- **Runtime**: Node.js v20+
- **Framework**: Express.js
- **Database**: SQLite (`events.db`) using `better-sqlite3`.
  - *Production Note*: Requires persistent storage (e.g., AWS EFS) when deployed on containers.
- **Frontend**: Vanilla HTML/CSS/JS (no build step required).

## 2. Integration Points

### A. CAS Authentication
**File to Modify**: [`routes/auth.js`](./routes/auth.js)
**Target Route**: `POST /login`

*   **Action**: Replace the current local UUID/password verification with your CAS client redirection logic.
*   **Callback**: Ensure the CAS callback matches the `username` (NetID) against the `counsellors` table before issuing the JWT session.

### B. Outlook Email Notifications
**Files to Modify**: 
1. `routes/counsellor.js` (New Submission)
2. `routes/admin.js` (Event Confirmation)

#### Trigger 1: New Event Submission
**Location**: [`routes/counsellor.js`](./routes/counsellor.js)
**Context**: Route `POST /submissions` (inside the successful DB transaction).

*   **Requirement**: Send an email to the **Admin Team** notifying them of a new request.
*   **Data Available**: `req.user.username` (Submitter), `req.body` (Event details).

#### Trigger 2: Event Confirmation & Staffing
**Location**: [`routes/admin.js`](./routes/admin.js)
**Context**: Route `PUT /submissions/:id/finalize` (inside the successful DB transaction).

*   **Requirement**: Send emails to:
    1.  **The Submitter** (User who created the event).
    2.  **All Assigned Staff** (Counsellors selected in `counsellor_ids`).
*   **Data Available**: 
    - `selected` array (Contains email/contact info of assigned staff if you add it to the DB schema).
    - `sent_by_counsellor_id` (ID of the original submitter).

## 3. Deployment Notes
- **Dockerfile**: Included in root. Uses `node:20-alpine`.
- **Persistence**: Ensure `events.db` is stored on a mounted volume. Configure `DATA_DIR` env var to point to that volume (e.g., `/mnt/data`).
- **Environment Variables**:
  - `JWT_SECRET`: Must be changed for production.
  - `PORT`: Defaults to 3000.
