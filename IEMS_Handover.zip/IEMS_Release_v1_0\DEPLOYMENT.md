# AWS Fargate Deployment Guide

This application handles its own state using SQLite (`events.db`). For AWS Fargate (which is ephemeral), you **MUST** configure persistent storage (EFS) or you will lose all data every time the server restarts.

## Prerequisites
- AWS Account
- Docker installed locally
- AWS CLI installed and configured

## 1. Dockerize & Push
Build and push your image to Amazon ECR (Elastic Container Registry).

```bash
# 1. Login to ECR
aws ecr get-login-password --region <region> | docker login --username AWS --password-stdin <aws_account_id>.dkr.ecr.<region>.amazonaws.com

# 2. Build
docker build -t counsellor-app .

# 3. Tag & Push
docker tag counsellor-app:latest <aws_account_id>.dkr.ecr.<region>.amazonaws.com/counsellor-app:latest
docker push <aws_account_id>.dkr.ecr.<region>.amazonaws.com/counsellor-app:latest
```

## 2. Infrastructure Setup (EFS)
You need a persistent filesystem for the database.

1. Go to **AWS EFS** console.
2. Create a **File System**.
3. Note the **FileSystem ID** (e.g., `fs-12345678`).
4. Ensure the Security Group for EFS allows inbound NFS (port 2049) from your Fargate tasks' Security Group.

## 3. Fargate Task Definition
Create a new Task Definition in ECS.

### Container Config
- **Image**: Your ECR URI.
- **Port Mappings**: 3000 (tcp).
- **Environment Variables**:
  - `NODE_ENV`: `production`
  - `JWT_SECRET`: (Set a long secure random string)
  - `ADMIN_USERNAME`: (Your desired admin user)
  - `ADMIN_PASSWORD`: (Your desired admin password)
  - `DATA_DIR`: `/mnt/data` (This matches the mount point below)

### Storage Config (Crucial!)
1. Under **Volumes**, add a new volume:
   - **Name**: `sqlite-data`
   - **Volume Type**: EFS
   - **FileSystem ID**: (Your fs-xxxx ID)
2. Under **Container Definitions** > **Mount Points**:
   - **Container Path**: `/mnt/data`
   - **Source Volume**: `sqlite-data`

## 4. Run the Service
1. Create a **Service** using your Task Definition.
2. Use an **Application Load Balancer (ALB)** mapping port 80/443 -> Container Port 3000.
3. **Health Check Path**: `/login.html` (or separate `/health` if added).

## Troubleshooting
- **Logs**: Check CloudWatch logs if the task stops immediately.
- **Database Errors**: If you see "ReadOnly" or "IO Error", check your EFS Security Group allows NFS traffic from the ECS Task.

> **Note**: SQLite on EFS works well for low-to-medium traffic. For high concurrency, ensure only ONE task is running (`Desire Count: 1`) to avoid locking issues, or consider migrating to AWS RDS (PostgreSQL/MySQL) if scaling is needed.
